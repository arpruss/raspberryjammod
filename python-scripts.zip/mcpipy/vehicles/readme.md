Minecraft TIE Fighter vehicle copyright (c) 2015 C. Pruss and D.  Pruss
Minecraft X-Wing Fighter vehicle copyright (c) 2015 C. Pruss
Unlimited free distribution permitted