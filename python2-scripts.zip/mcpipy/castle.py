#
# MIT-Licensed code by Alexander Pruss
#

from mc import *

# Note: the first set of coordinates must be smaller than the second
def wall(x1,y1,z1, x2,y2,z2, baseHeight, altHeight, block):
    x = x1
    z = z1

    while True:
        if (x-x1+z-z1) % 2 == 0:
            height = altHeight
        else:
            height = baseHeight
        mc.setBlocks(x,y1,z,x,y1+height,z,block)
        if x >= x2 and z >= z2:
            return
        if x < x2:
            x = x + 1
        if z < z2:
            z = z + 1

def crenellatedSquare(x1,y1,z1,width,height,altHeight,block):
    wall(x1, y1, z1, x1+width-1, y1, z1, height, altHeight,block)
    wall(x1, y1, z1, x1, y1, z1+width-1, height, altHeight,block)
    wall(x1+width-1, y1, z1, x1+width-1, y1, z1+width-1, height, altHeight,block)
    wall(x1, y1, z1+width-1, x1+width-1, y1, z1+width-1, height, altHeight,block)

def square(x,y,z,width,height,block):
    crenellatedSquare(x,y,z,width,height,height,block)

def crenellatedSquareWithInnerWall(x,y,z,width,baseHeight,altHeight,block):
    crenellatedSquare(x,y,z,width,baseHeight,altHeight,block)
    square(x+1,y,z+1,width-2,baseHeight-1,block)

def tower(x,y,z,width,baseHeight,altHeight,innerHeight,block):
    crenellatedSquareWithInnerWall(x,y,z,width,baseHeight,altHeight,block)
    mc.setBlocks(x+2,y+innerHeight-1,z+2, x+width-3,y+innerHeight-1,z+width-3, block)

mc = Minecraft()
pos = mc.player.getTilePos()
mc.postToChat(pos)

WALLSIZE = 51
groundY = mc.getHeight(pos.x, pos.z)

# outer walls
crenellatedSquareWithInnerWall(pos.x,groundY,pos.z, WALLSIZE, 9, 10, STONE_BRICK)

# towers
tower(pos.x-7,groundY,pos.z-7, 9, 12, 13, 11, OBSIDIAN)
tower(pos.x+WALLSIZE-2,groundY,pos.z+WALLSIZE-2, 9, 12, 13, 11, OBSIDIAN)
tower(pos.x-7,groundY,pos.z+WALLSIZE-2, 9, 12, 13, 11, OBSIDIAN)
tower(pos.x+WALLSIZE-1,groundY,pos.z-7, 9, 12, 13, 11, OBSIDIAN)

# keep
keepStartX = pos.x+WALLSIZE/4
keepStartZ = pos.z+WALLSIZE/4
KEEPWIDTH = WALLSIZE / 6 * 3
tower(keepStartX,groundY, keepStartZ,KEEPWIDTH, 16, 17, 15, OBSIDIAN)

# moat
moatStartX = pos.x - 12
moatStartZ = pos.z - 12
moatInnerSize = WALLSIZE+24

for i in range(6):
    square(moatStartX-i,groundY-2,moatStartZ-i,moatInnerSize+2*i,1,WATER_FLOWING)
