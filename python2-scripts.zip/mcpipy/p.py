from turtle import *
t = Turtle()
t.roll(45)
t.startface()
for i in range(5):
 t.go(20)
 t.yaw(360/5)
