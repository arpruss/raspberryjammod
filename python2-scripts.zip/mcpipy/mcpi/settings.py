POCKET_EDITION = 0
PI = 1
DESKTOP = 2

minecraftType = DESKTOP
isPE = False
