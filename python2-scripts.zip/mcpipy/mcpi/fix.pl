while(<>) {
    s/[\r\n]//g;
    print uc($_)." = ".$_."\n";
}