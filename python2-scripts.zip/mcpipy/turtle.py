#
# Public domain code by Alexander Pruss
#
# for backwards compatibility with earlier versions of
# Pruss's instructable
from mcturtle import *
