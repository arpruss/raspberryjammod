import turtle
t = turtle.Turtle()
for i in range(7):
    t.go(50)
    t.right(180.-180./7)
