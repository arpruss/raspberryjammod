# If you need to connect to a RaspberryJamMod server that uses authentication, edit these
# lines to set your username and password, and rename this file to security.py
AUTHENTICATION_USERNAME=None
AUTHENTICATION_PASSWORD=None
